/**
 * File name: Move.java
 * Short description:
 * IST 242 Assignment:
 *
 * @author Peter Bachman
 * @version 1.01 11/2/2022
 */

public class Move {
    // Instance Variables -- define your private data


    // Constructors
    public Move() {
        // initialize default values
    }

    public Move(int data) // pass in data to initialize variables
    {
    }

    // Set methods - one set method for each instance variable defined above
    //             - purpose is to pass in a value stored in the private variable

    // Get methods - one get method for each instance variable defined above
    //             - purpose is to return the value stored in the private variable

    // Additional methods -- such as for calculation, display

    public String toString() {
        // return data as a String
        return "";
    }


}