public class Rules {
//    public static void main(String[] args) {
//        System.out.println("Mancala Game GUI!");
//        MancalaGUI gui = new MancalaGUI();
//
//        make a mancala game;
//
//
//        public mancala getGame () {
//            return game;
//
//            //display the game board  as an image;
//            //use java swing to display the game board;
//
//            create a new game;
//            create a new game by clicking a button called "new game";
//
//            set initial stones to 4;
//            assign 4 stones to each pit;
//            assign 0 stones to each mancala;
//            use a for loop to assign 4 stones to each pit;
//            create swing gridbaglayout to display the game board;
//            create a new game by clicking a button called "new game";
//            move stones should be a method that is triggered by clicking a pit;
//            move stones should be a method that is triggered by clicking a pit;
//            after each move, the game should check if the game is over;
//            after each move, the game should check if the game is over;
//            if the game is over, the game should display the winner;
//            if the game is over, the game should display the winner;
//            if the player clicks a pit that is empty, the game should not move;
//            if the player clicks a pit that is empty, the game should not move;
//            if player1 has more stones than player2, player1 wins;
//            if player1 moves last stone to his mancala, player1 gets another turn;
//
//            if player1 has ended his turn, player2 gets a turn;
//            player2 can only move stones in his pits;
//
//            if player2 has more stones than player1, player2 wins;
//
//            if player2 moves last stone to his mancala, player2 gets another turn;
//            the number pf stones in each pit should be displayed;
//            the number pf stones in each pit should be displayed;
//
//            each stone is displayed as a circle;
//            each stone maintains its color;
//            each stone is displayed as a circle;
//            each stone maintains its color;
//            any stone that is moved should be displayed as a circle;
//            and stone in a pit can be moved by clicking on it;
//            that stone is then moved to the next pit;
//
//            final initial stones 4 in each pit;
//            start with player 1;
//            the stone move takes place on a java transparent panel;
//            that panel is above the game board which is an image;
//            underneath the game board is a panel that displays the number of stones in each pit;
//            that panel has a gridbaglayout;
//            the gridbaglayout has 14 panels;
//
//            the first panel is for player 1 's mancala;
//            the second panel is for player 1 's pit 1;
//            the third panel is for player 1 's pit 2;
//            the fourth panel is for player 1 's pit 3;
//            the fifth panel is for player 1 's pit 4;
//            the sixth panel is for player 1 's pit 5;
//            the seventh panel is for player 1 's pit 6;
//            the eighth panel is for player 2 's pit 1;
//            the ninth panel is for player 2 's pit 2;
//            the tenth panel is for player 2 's pit 3;
//            the eleventh panel is for player 2 's pit 4;
//            the twelfth panel is for player 2 's pit 5;
//            the thirteenth panel is for player 2 's pit 6;
//            the fourteenth panel is for player 2 's mancala;
//            the game board is an image;
//            movement uses java animation using x and y coordinates;
//            a mouse listener is used to detect mouse clicks;
//            a mouse listener is used to detect mouse clicks;
//            upon mouse click, the stone is moved to the next pit;
//            each pit has a number of stones;
//            each pit has a defined x and y coordinate;
//            the pit is an oval;
//            the visible stones must fit inside the pit;
//            additional stones that are more than 4 are stacked on top of each other;
//            when a player 's move ends on an his own pit which is empty if there are any stones on the opposite side,
//            they are removed an dor to that players mancala as a capture;
//            this move is called a "capture" move;
//            completing a "capture" move gives the player another turn;
//            if a player 's move ends on his own mancala, he gets another turn;
//            a capture move plays a sound;
//            when a player wins, that move plays a sound
//            the series of moves is called a "turn";
//            a turn is a series of moves;
//            the progamming of a turn is a method;
//            the game is designed in the same format as an IST242
//            class project with appropriate comments and documentation ;
//            moving the stones is a method;
//            moving the stones is a java animation;
//            the individual stones are moved in a sequential order;
//            the individual stones are moved in a sequential order starting with the first stone clicked on;
//            after the first stone is clicked which is any stone in any pit that is owned by the player, all stones in
//            that pit are moved with each stone being deposited in subsequent pits;
//
//            when a player 's move ends on an his own pit which is empty if there are any stones on the opposite side,
//
//            player 1 goes first;
//            player 2 goes second;
//
//
//        }
   }