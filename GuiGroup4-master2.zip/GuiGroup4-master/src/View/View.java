package src.View;

public class View {
    // Instance Variables
    private MainFrame mf;
    private InitialPanel iPanel;
    private CenterlPanel clPanel;
    private CenterRPanel crPanel;
    private TopPanel tPanel;
    private PitPanel pPanel;


}
