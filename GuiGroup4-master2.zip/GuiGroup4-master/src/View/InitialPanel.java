package View;

import java.awt.*;

public class InitialPanel {

    // Instance Variables -- define your private data
    private InitialPanel ip;


    // Constructors
    public InitialPanel() {
        // initialize default values
        super();
        setLayout(new BorderLayout());
        ip = new InitialPanel();
        add(ip);
    }

    // Get methods - one get method for each instance variable defined above
    //             - purpose is to return the value stored in the private variable
    public void setupPanel(int rows, int cols){
        setLayout(new GridLayout(2, 6));
    }


    public InitialPanel getIp() {
        return ip;
    }

}


