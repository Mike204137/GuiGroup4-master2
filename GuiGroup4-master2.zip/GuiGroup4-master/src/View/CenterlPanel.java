package View;

import java.awt.*;

/**
 * File name: CenterlPanel.java
 * Short description:
 * IST 242 Assignment:
 *
 * @author Peter Bachman
 * @version 1.01 11/2/2022
 */

public class CenterlPanel {
    // Instance Variables -- define your private data
    private CenterlPanel clp;

    // Constructors
    public CenterlPanel() {
        // initialize default values
        super();
        setLayout(new GridLayout());
        clp = new CenterlPanel();
        add(clp);
    }

    public CenterlPanel(int data) // pass in data to initialize variables
    {
    }



    // Get methods - one get method for each instance variable defined above
    //             - purpose is to return the value stored in the private variable
    public void setupPanel(int )

    public CenterlPanel getClp() {
        return clp;
    }






}