package src.View;

public class MainFrame {
    // Instance Variables
    private InitialPanel ip;

    // Constructors
    public MainFrame() {
        // Initialize default values
        super ("Mancala Board Game");
        ip = new InitialPanel();
        add(ip);

    }
}
