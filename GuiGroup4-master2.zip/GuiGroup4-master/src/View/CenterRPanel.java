package src.View;

import java.awt.*;

public class CenterRPanel {

    // Instance Variables -- define your private data
    private CenterRPanelPanel crp;

    // Constructors
    public CenterRPanel() {
        // initialize default values
        super();
        setLayout(new GridLayout());
        crp = new CenterRPanel();
        add(crp);
    }

    public CenterRPanel(int data) // pass in data to initialize variables
    {
    }



    // Get methods - one get method for each instance variable defined above
    //             - purpose is to return the value stored in the private variable
    public void setupPanel(int )

    public CenterRPanelPanel getCrp() {
        return crp;
    }
}
