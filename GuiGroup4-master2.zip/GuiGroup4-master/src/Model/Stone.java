package Model;

public class Stone {
}
